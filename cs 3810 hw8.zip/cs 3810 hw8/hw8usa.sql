/*
Mark Huntington
CS 3810
HW #8: PGIS lesson
*/

CREATE TABLE usa."census 2010"
(
    state character varying(50) COLLATE pg_catalog."default" NOT NULL,
    total integer,
    male integer,
    female integer,
    white integer,
    black integer,
    amind integer,
    asian integer,
    hawaiin integer,
    other integer,
    mixed integer,
    CONSTRAINT "census 2010_pkey" PRIMARY KEY (state)
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE usa."census 2010"
    OWNER to postgres;
	

CREATE TABLE usa.cities
(
    gid integer NOT NULL DEFAULT nextval('usa.cities_gid_seq'::regclass),
    uident double precision,
    popclass double precision,
    name character varying(40) COLLATE pg_catalog."default",
    capital double precision,
    stateabb character varying(10) COLLATE pg_catalog."default",
    country character varying(10) COLLATE pg_catalog."default",
    geom geometry(Point,4269),
    CONSTRAINT cities_pkey PRIMARY KEY (gid)
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE usa.cities
    OWNER to postgres;

-- Index: cities_geom_idx

-- DROP INDEX usa.cities_geom_idx;

CREATE INDEX cities_geom_idx
    ON usa.cities USING gist
    (geom)
    TABLESPACE pg_default;
	
	
CREATE TABLE usa.states
(
    gid integer NOT NULL DEFAULT nextval('usa.states_gid_seq'::regclass),
    name character varying(110) COLLATE pg_catalog."default",
    state character varying(254) COLLATE pg_catalog."default",
    pop2008 double precision,
    rank double precision,
    sub_region character varying(50) COLLATE pg_catalog."default",
    geom geometry(MultiPolygon,4269),
    CONSTRAINT states_pkey PRIMARY KEY (gid)
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE usa.states
    OWNER to postgres;

-- Index: states_geom_idx

-- DROP INDEX usa.states_geom_idx;

CREATE INDEX states_geom_idx
    ON usa.states USING gist
    (geom)
    TABLESPACE pg_default;