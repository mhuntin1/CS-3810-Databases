/*
Mark Huntington
CS 3810
HW #8: PGIS nyc_poi schema
*/

CREATE TABLE nyc_poi.lines
(
    gid integer NOT NULL DEFAULT nextval('nyc_poi.lines_gid_seq'::regclass),
    name character varying(50) COLLATE pg_catalog."default",
    geom geometry(LineString,4269),
    CONSTRAINT lines_pkey PRIMARY KEY (gid)
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE nyc_poi.lines
    OWNER to postgres;
	
CREATE TABLE nyc_poi.mixed
(
    gid integer NOT NULL DEFAULT nextval('nyc_poi.mixed_gid_seq'::regclass),
    name character varying(50) COLLATE pg_catalog."default",
    geom geometry(Geometry,4269),
    CONSTRAINT mixed_pkey PRIMARY KEY (gid)
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE nyc_poi.mixed
    OWNER to postgres;
	
CREATE TABLE nyc_poi.polys
(
    gid integer NOT NULL DEFAULT nextval('nyc_poi.polys_gid_seq'::regclass),
    name character varying(50) COLLATE pg_catalog."default",
    geom geometry(Polygon,4269),
    CONSTRAINT polys_pkey PRIMARY KEY (gid)
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE nyc_poi.polys
    OWNER to postgres;
	
	
CREATE TABLE nyc_poi.pts
(
    gid integer NOT NULL DEFAULT nextval('nyc_poi.pts_gid_seq'::regclass),
    name character varying(50) COLLATE pg_catalog."default",
    geom geometry(Point,4269),
    CONSTRAINT pts_pkey PRIMARY KEY (gid)
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE nyc_poi.pts
    OWNER to postgres;